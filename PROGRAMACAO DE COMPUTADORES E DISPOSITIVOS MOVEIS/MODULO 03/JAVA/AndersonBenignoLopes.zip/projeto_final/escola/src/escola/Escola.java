package escola;

import escola.forms.PrincipalForm;

/**
 *
 * @author Anderson Lopes
 */
public class Escola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PrincipalForm PrincipalForm = new PrincipalForm();
        PrincipalForm.setVisible(true);
        
    }

}
